# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
from itemadapter import ItemAdapter


class OwaspPipeline:
    def process_item(self, item, spider):
        return item

import sqlite3

class SQLitePipeline:

    def open_spider(self, spider):
        # conecta ao DB (se não existir, cria)
        self.conn = sqlite3.connect("owasp.db")
        self.cursor = self.conn.cursor()

        # cria tabela se não existir
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS owasp (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                texto TEXT
            )
        """)
        self.conn.commit()

    def close_spider(self, spider):
        self.conn.close()

    def process_item(self, item, spider):
        self.cursor.execute("""
            INSERT INTO owasp (texto) VALUES (?)
        """, (item["texto"],))
        self.conn.commit()

        return item




import json




class JsonWriterPipeline:

    def open_spider(self, spider):
        # abre arquivo JSONL (json line-by-line)
        self.file = open("owasp.json", "w", encoding="utf-8")

    def close_spider(self, spider):
        self.file.close()

    def process_item(self, item, spider):
        line = json.dumps(item, ensure_ascii=False) + "\n"
        self.file.write(line)
        return item



