import scrapy

class OwaspTeste(scrapy.Spider):
    name = "owasp"
    allowed_domains = ["mas.owasp.org"]
    start_urls = ["https://mas.owasp.org/MASWE/"]

    def start_requests(self):
        for url in self.start_urls:
            yield scrapy.Request(
                url,
                meta={
                    "playwright": True,
                    "playwright_page_methods": [
                        {
                            "method": "wait_for_timeout",
                            "args": [2000]    # espera 2 segundos
                        }
                    ]
                }
            )

    def parse(self, response):
        for item in response.css("li.md-nav__item"):
            texto = item.css("span::text").get()

            # evita erro se texto for None
            if not texto:
                continue

            # Filtra apenas se contiver "MASWE"
            if ("MASWE" in texto) or ("MASTG" in texto):
                yield {
                    "texto": texto
                }
